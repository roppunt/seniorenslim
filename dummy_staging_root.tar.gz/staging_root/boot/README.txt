Dummy boot directory
