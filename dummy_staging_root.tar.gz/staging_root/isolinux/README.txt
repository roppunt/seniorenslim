Dummy isolinux directory
